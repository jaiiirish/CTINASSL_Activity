const router = require('express').Router();
const UserController = require('../controller/userController');

router.get('/', UserController.getAllUsers);
router.post('/create', UserController.createUser);
router.put('/update/:id', UserController.updateUser);
router.delete('/:id', UserController.deleteUser);

module.exports = router;