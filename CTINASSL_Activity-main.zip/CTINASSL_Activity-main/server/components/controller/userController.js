const User = require("../models/userModel");

const UserController = {
    // Get all users
    getAllUsers: async (request, response) => {
        try {
            const users = await User.find();
            response.status(200).json(users);

        } catch (error) {
            response.status(500).json({
                message: "Error retrieving users",
                error: error.message
            })
        }

    }

    createUser: async (request, response) => {
        const { name, email, password } = request.body;

        try {
            //Check if a user is existing
            const existingUser = await User.findOne({ email })
            if (existingUser) {
                return response.status(409).json({
                    message: "User with this email already exists",
                    success: false,
                    user
                })
            }

            const user = new User({
                name: name,
                email: email,
                password: password
            });

            await user.save();
            response.status(201).json

        } catch (error) {
            response.status(500).json({
                message: "Error creating user",
                error: error.message
            })
        }
    }

    updateUser: async (request, response) => {
        try {
            const user = await User.findById(request.params.id);
            if(!user) {
                return response.status(404).json ({
                    message: "User not found",

                })
            }
        } catch (error) {
            response.status(500).json({
                message: "Error updating user",
                error: error.message
            })
        }
    }

    //delete user
    deleteUser: async (request, response) => {
        try{
            await User.findByIdAndDelete(request.params.id);
            response.status(200).json({
                message: "User deleted successfully",
                success: true
            })

        } catch (error) {
            response.status(500).json({
                message: 'Error deleting user',
                error: error.message
            })
        }
    }
}

module.exports = UserController;