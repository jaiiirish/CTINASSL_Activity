const User = require("../models/userModel");

const UserController = {
    // Get all users
    getAllUsers: async (request, response) => {
        try {
            const users = await User.find().select("-password");
            response.status(200).json({
                message: "Users retrieved successfully",
                success: true,
                users
            });

        } catch (error) {
            response.status(500).json({
                message: "Error retrieving users",
                error: error.message
            });
        }

    },

    // Create user
    createUser: async (request, response) => {
        const { name, email, password } = request.body;

        try {
            //Check if a user is existing
            const existingUser = await User.findOne({ email })
            if (existingUser) {
                return response.status(409).json({
                    message: "User with this email already exists",
                    success: false,
                });
            }

            const user = new User({
                name,
                email,
                password
            });

            await user.save();
            
            response.status(201).json({
                message: "User created successfully",
                success: true,
                user: {
                    _id: user._id,
                    name: user.name,
                    email: user.email
                }
            });

        } catch (error) {
            response.status(500).json({
                message: "Error creating user",
                error: error.message
            });
        }
    },

    // Update user
    updateUser: async (request, response) => {
        try {
            const user = await User.findById(
                request.params.id,
                request.body,
            {
                new: true,
                runValidations: true
            }
        ).select("-password");

            if (!user) {
                return response.status(404).json ({
                    message: "User not found",
                    success: false
                });
            }

            response.status(200).json({
                message: "User updated successfully",
                success: true,
                user
            });

        } catch (error) {
            response.status(500).json({
                message: "Error updating user",
                error: error.message
            });
        }
    },

    //delete user
    deleteUser: async (request, response) => {
        try{
            const user = await User.findByIdAndDelete(request.params.id);
            
            if (!user) {
                return response.status(404).json({
                    message: "User not found",
                    success: false
                });
            }
            
            response.status(200).json({
                message: "User deleted successfully",
                success: true
            });

        } catch (error) {
            response.status(500).json({
                message: 'Error deleting user',
                error: error.message
            });
        }
    }
};

module.exports = UserController;