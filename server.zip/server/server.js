const express = require('express');
const app = express();

app.use(express.json());
app.use(express.urlencoded( {extended: true} ));

app.get('/', (request, response) => {
    response.status(200).send('Jairish Dacquel');
});

under.post('/greetings', (request, response) => {
	const { name, course, section } = request.body;
	console.log(request,body,name);
	response.status(200).json({
		name: name,
		course: course,
		section: section,
		message: `Hello ${name}, welcome to the ${course}, section ${section}!`
	});
});

app.listen(8000, error => {
    if(error) {
        console.error("Error Starting Server: ", error);
        process.exit(1);
	};
	console.log("Server running on port: ", 8000);
})